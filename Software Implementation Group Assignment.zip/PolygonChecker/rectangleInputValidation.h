#pragma once

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define ASCIIZERO 48
#define ASCIININE 57
#define ASCIIMINUS 45

bool ValidateUserInputForPoints(char*);