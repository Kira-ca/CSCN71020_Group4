#pragma once
void printWelcome();
int printShapeMenu();
int* getTriangleSides(int* triangleSides);