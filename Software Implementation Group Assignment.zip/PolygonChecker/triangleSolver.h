#pragma once

#define DEGREECONVERSION	(180 / 3.1415)
#define DEGREETOTAL			180

char* analyzeTriangle(int side1, int side2, int side3);
void FindAnglesInTriangleAndPrint(double side1, double side2, double side3);

char* analyzeTriangle(int side1, int side2, int side3);