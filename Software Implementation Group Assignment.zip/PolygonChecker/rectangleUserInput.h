#pragma once

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

#define ZERO		0
#define ONE			1
#define TWO			2
#define MAXSTRLEN 100

void GetUserInputPoints(int* pointArrays);